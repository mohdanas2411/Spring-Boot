package com.SpringBoot.Spring_JDBC_Imple;

import java.util.Date;
import java.util.List;

import org.hibernate.engine.jdbc.connections.spi.DataSourceBasedMultiTenantConnectionProviderImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.SpringBoot.Spring_JDBC_Imple.bean.Person;
import com.SpringBoot.Spring_JDBC_Imple.dao.PersonJdbcDao;

@SpringBootApplication
public class SpringJdbcImpleApplication implements CommandLineRunner {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	PersonJdbcDao personJdbcDao;
	
	public static void main(String[] args) {
		SpringApplication.run(SpringJdbcImpleApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		List<Person> findAll = personJdbcDao.findAll();
		logger.info("All person list {}",findAll);
		
		Person findById = personJdbcDao.findById(2);
		logger.info("find by id {}",findById);
		
		int deleteById = personJdbcDao.deleteById(2);
		logger.info("Number of person Deleted {}",deleteById);
		
		int insertcount = personJdbcDao.insert(new Person(4,"Ali","New Delhi",new Date()));
		logger.info("Number of person inserted {}",insertcount);
		
		int updatedcount = personJdbcDao.update(new Person(4,"Ali","Delhi 6",new Date()));
	logger.info("Number of person Updated {}",updatedcount);
		
		List<Person> findAll2 = personJdbcDao.findAll();
		logger.info("All person list {}",findAll2);
//		
	}

}
